package com.projeto.documentacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
